
import React, { useState } from 'react';
import { Button, Typography, Slider } from '@mui/material';

const questions = [
  { text: 'I enjoy exploring new ideas.', trait: 'openness' },
  { text: 'I stay organized and meet deadlines.', trait: 'conscientiousness' }
];

const BigFiveQuestionnaire = ({ onComplete }) => {
  const [responses, setResponses] = useState({ openness: 0, conscientiousness: 0, extraversion: 0, agreeableness: 0, neuroticism: 0 });

  const handleSliderChange = (trait) => (event, value) => {
    setResponses(prev => ({ ...prev, [trait]: value }));
  };

  const handleSubmit = () => {
    onComplete({ bigFiveScores: responses, fourFTypeScores: { Fight: 0, Freeze: 0, Fawn: 0, Flight: 0 } });
  };

  return (
    <div>
      {questions.map((q, index) => (
        <div key={index}>
          <Typography>{q.text}</Typography>
          <Slider value={responses[q.trait]} onChange={handleSliderChange(q.trait)} max={100} />
        </div>
      ))}
      <Button onClick={handleSubmit} variant="contained">Submit</Button>
    </div>
  );
};

export default BigFiveQuestionnaire;
