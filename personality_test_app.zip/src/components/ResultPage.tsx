
import React from 'react';
import { Typography } from '@mui/material';

const ResultPage = ({ mbtiType }) => (
  <div>
    <Typography variant="h4">Your MBTI Type is: {mbtiType}</Typography>
  </div>
);

export default ResultPage;
