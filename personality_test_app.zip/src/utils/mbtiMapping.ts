
import { weightedEuclideanDistance } from './scoring';

const MBTIProfiles = [
  { name: 'INTJ', traits: { openness: 0.85, conscientiousness: 0.8, extraversion: 0.3, agreeableness: 0.35, neuroticism: 0.4 }, mode: 'Freeze' }
];

export const matchMBTIType = (profile, primary4F) => {
  const candidates = MBTIProfiles.filter(p => p.mode === primary4F);
  let closestType = '';
  let closestDistance = Infinity;

  candidates.forEach(candidate => {
    const distance = weightedEuclideanDistance(profile, candidate.traits, profile);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestType = candidate.name;
    }
  });

  return closestType;
};
