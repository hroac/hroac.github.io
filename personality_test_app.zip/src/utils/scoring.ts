
export const weightedEuclideanDistance = (profile, ideal, weights) => {
  return Math.sqrt(Object.keys(profile).reduce((sum, key) => {
    const diff = profile[key] - ideal[key];
    return sum + weights[key] * Math.pow(diff, 2);
  }, 0));
};

export const determinePrimary4FType = (profile) => {
  const fourFIdealProfiles = {
    Fight: { openness: 0.7, conscientiousness: 0.6, extraversion: 0.8, agreeableness: 0.3, neuroticism: 0.5 },
    Freeze: { openness: 0.4, conscientiousness: 0.8, extraversion: 0.3, agreeableness: 0.3, neuroticism: 0.3 }
  };
  return Object.keys(fourFIdealProfiles).reduce((a, b) => (
    weightedEuclideanDistance(profile, fourFIdealProfiles[a], profile) <
    weightedEuclideanDistance(profile, fourFIdealProfiles[b], profile) ? a : b
  ));
};
