
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import BigFiveQuestionnaire from './components/BigFiveQuestionnaire';
import ResultPage from './components/ResultPage';
import TRPIExplanationPage from './components/TRPIExplanationPage';
import { matchMBTIType, determinePrimary4FType } from './utils/mbtiMapping';
import { Button, Box } from '@mui/material';

function App() {
  const [mbtiType, setMbtiType] = useState<string>('');

  const handleComplete = (responses) => {
    const primary4F = determinePrimary4FType(responses.bigFiveScores);
    const mbti = matchMBTIType(responses.bigFiveScores, primary4F);
    setMbtiType(mbti);
  };

  return (
    <Router>
      <Box padding={3}>
        <Box display="flex" justifyContent="space-around" marginBottom={2}>
          <Button component={Link} to="/" variant="outlined">Start Test</Button>
          <Button component={Link} to="/trpi-explanation" variant="outlined">TRPI Explanation</Button>
          <Button component={Link} to="/result" variant="outlined">View Result</Button>
        </Box>

        <Routes>
          <Route path="/" element={<BigFiveQuestionnaire onComplete={handleComplete} />} />
          <Route path="/trpi-explanation" element={<TRPIExplanationPage />} />
          <Route path="/result" element={<ResultPage mbtiType={mbtiType} />} />
        </Routes>
      </Box>
    </Router>
  );
}

export default App;
